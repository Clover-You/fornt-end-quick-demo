/*
 * @Author: Yollx
 * @Date: 2020-09-25 10:13:02
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-26 11:26:45
 * @Descripttion: 二次封装axios
 * 
 */
import axios from "axios";
import axiosError from "./lib/axiosError"
import adapter from "./lib/adapter"


const NODE_ENV = process.env.NODE_ENV;
const pro = '';
const dev = 'http://rap2api.taobao.org/app/mock/263917/';
const SERVICE_URL = NODE_ENV == "development" ? dev : pro;

const service = axios.create({
  withCredentials: true,
  crossDomain: true,
  baseURL: SERVICE_URL,
  timeout: 600
})

service.defaults.adapter = adapter;

service.defaults.retry = 5; // 设置请求次数
service.defaults.retryDelay = 1000;// 重新请求时间间隔

// request拦截器,在请求之前做一些处理
service.interceptors.request.use(
  config => {
    return config;
  },
  error => {
    // console.log(error); // for debug
    return Promise.reject(error);
  }
);

//配置成功后的拦截器
service.interceptors.response.use(res => {
  if (res.status == 200) {
    return res;
  } else {
    return Promise.reject(res);
  }
}, err => axiosError(err, service))


export default service;