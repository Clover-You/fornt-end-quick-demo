/*
 * @Author: UpYou
 * @Date: 2020-09-25 21:48:21
 * @LastEditTime: 2020-09-26 11:48:34
 * @Descripttion: axios401错误配置
 * 
 */

// 重试请求
import interceptorsError from "../lib/interceptorsError";
import store from 'store/index'

/* 需要传入axios错误配置 */
export default function (err, axios) {
  const config = err.config;// axios请求配置
  store.dispatch("getToken").then(function () {
    config.headers["Authorization"] = store.state.cnrToken.cnr_token;
  });
  return interceptorsError(axios, config);
}